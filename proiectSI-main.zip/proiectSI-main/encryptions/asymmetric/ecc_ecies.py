from ecies import encrypt, decrypt
from ecies.utils import generate_eth_key


def generate_keys():
    secp = generate_eth_key()
    priv = secp.to_hex()
    pub = secp.public_key.to_hex()
    return str(pub), str(priv)


def encrypt_file(input_file_path, output_file_path, public_key_text):
    public_key = public_key_text
    with open(input_file_path, 'rb') as file:
        plaintext = file.read()
        encrypted_text = encrypt(public_key, plaintext)

        with open(output_file_path, 'wb') as output_file:
            output_file.write(encrypted_text)


def decrypt_file(input_file_path, output_file_path, private_key_text):
    private_key = private_key_text

    with open(input_file_path, 'rb') as file:
        encrypted_text = file.read()

        decrypted_text = decrypt(private_key, encrypted_text)

        with open(output_file_path, 'wb') as output_file:
            output_file.write(decrypted_text)
