import subprocess
import tempfile

import psutil


def generate_keys(keysize=2048):
    print(keysize)
    private_key_path = 'private.pem'
    public_key_path = 'public.pem'
    subprocess.run(["openssl", "genpkey", "-algorithm", "RSA", "-outform", "PEM", "-out", private_key_path,
                    "-pkeyopt", "rsa_keygen_bits:{}".format(keysize)], stderr=subprocess.PIPE)


    subprocess.run(["openssl", "rsa", "-in", private_key_path, "-out", public_key_path, "-pubout"],
                   stderr=subprocess.PIPE)

    with open(private_key_path, "r") as private_key_file:
        private_key_text = private_key_file.read()
    with open(public_key_path, "r") as public_key_file:
        public_key_text = public_key_file.read()

    return public_key_text, private_key_text


def encrypt_file(input_file, output_file, public_key_text):
    public_key_text = public_key_text.encode('utf-8')

    with tempfile.NamedTemporaryFile(delete=False) as public_key_file:
        public_key_file.write(public_key_text)
        public_key_file.seek(0)

        return subprocess.Popen(
            ["openssl", "rsautl", "-encrypt", "-pubin", "-inkey", public_key_file.name, "-in", input_file, "-out",
             output_file])



def decrypt_file(input_file, output_file, private_key_text):
    private_key_text = private_key_text.encode('utf-8')

    with tempfile.NamedTemporaryFile(delete=False) as private_key_file:
        private_key_file.write(private_key_text)
        private_key_file.seek(0)

        return subprocess.Popen(["openssl", "rsautl", "-decrypt", "-inkey", private_key_file.name, "-in", input_file, "-out",
                        output_file])
