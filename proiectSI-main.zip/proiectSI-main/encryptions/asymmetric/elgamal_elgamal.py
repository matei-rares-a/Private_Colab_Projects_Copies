from elgamal.elgamal import Elgamal, CipherText, PublicKey, PrivateKey


def generate_keys():
    pub, priv = Elgamal.newkeys(128)
    a, b, c = pub.get()
    pub = str(a) + "_" + str(b) + "_" + str(c)
    a, b = priv.get()
    priv = str(a) + "_" + str(b)

    return pub, priv


def encrypt_file(input_file_path, output_file_path, public_key):
    public_key = PublicKey(*[int(x) for x in public_key.split("_")])
    with open(input_file_path, 'rb') as file:
        plaintext = file.read()

        encrypted_text = Elgamal.encrypt(plaintext, public_key)
        part1, part2 = encrypted_text.get()

        with open(output_file_path, 'w') as output_file:
            output_file.write(str(part1))
            output_file.write("\n")
            output_file.write(str(part2))


def decrypt_file(input_file_path, output_file_path, private_key):
    private_key = PrivateKey(*[int(x) for x in private_key.split("_")])

    with open(input_file_path, 'r') as file:
        part1, part2 = file.read().split("\n")
        decrypted_text = Elgamal.decrypt(CipherText(int(part1), int(part2)), private_key)

        with open(output_file_path, 'wb') as output_file:
            output_file.write(decrypted_text)
