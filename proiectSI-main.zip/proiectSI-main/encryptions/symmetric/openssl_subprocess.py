import subprocess
import psutil
# from importlib import resources
#12878565376
#12722933760
def get_memory_info():
    return {
        "total_memory": psutil.virtual_memory().total ,
        "available_memory": psutil.virtual_memory().available ,
        "used_memory": psutil.virtual_memory().used ,
        "memory_percentage": psutil.virtual_memory().percent
    }

def encrypt(algorithm, input_file, output_name, password):
    openssl_cmd = [
        'openssl', "enc",
        algorithm,
        '-a', '-pbkdf2', '-iter', '10000',
        '-in', input_file,
        '-out', output_name,
        '-pass', 'pass:' + password]
    return subprocess.Popen(openssl_cmd)
    # subprocess.run(openssl_cmd)


def decrypt(algorithm, input_file, output_file, password):
    openssl_cmd = [
        'openssl', "enc",
        '-d',  # decrypt
        algorithm,
        '-a',
        '-pbkdf2',
        '-iter', '10000',
        '-in', input_file,
        '-out', output_file,
        '-pass', 'pass:' + password
    ]
    return subprocess.Popen(openssl_cmd)


# def encrypt(input, output_name, password):
#     command = [
#         'libressl',  #incercare libressl daca instaleaza cnv
#         'enc',
#         '-aes-256-cbc',
#         '-salt',
#         '-in', input,
#         '-out', output_name,
#         '-k', password
#     ]
#     subprocess.run(command)


AES = "-aes256"
DES = "-des"
DESX = "-desx"
DES_EDE = "-des-ede"
DES_EDE3 = "-des3"
CAMELLIA = "-camellia256"
BLOWFISH = "-blowfish"
CAST = "-cast"
CAST5 = "-cast5-cbc"
CHACHA20 = "-chacha20"
IDEA = "-idea"
RC2 = "-rc2"
RC4 = "-rc4"
SEED = "-seed"
SM4 = "-sm4"
ARIA = "-aria256"

algo = RC4


def encrypt_aes(input_file, output_name, password):
    return encrypt(AES, input_file, output_name, password)


def decrypt_aes(input_file, output_file, password):
    return decrypt(AES, input_file, output_file, password)


def encrypt_des(input_file, output_name, password):
    return encrypt(DES, input_file, output_name, password)


def decrypt_des(input_file, output_file, password):
    return decrypt(DES, input_file, output_file, password)


def encrypt_3des(input_file, output_name, password):
    return encrypt(DES_EDE3, input_file, output_name, password)


def decrypt_3des(input_file, output_file, password):
    return decrypt(DES_EDE3, input_file, output_file, password)


def encrypt_blowfish(input_file, output_name, password):
    return encrypt(BLOWFISH, input_file, output_name, password)


def decrypt_blowfish(input_file, output_file, password):
    return decrypt(BLOWFISH, input_file, output_file, password)


def encrypt_cast(input_file, output_name, password):
    return encrypt(CAST, input_file, output_name, password)


def decrypt_cast(input_file, output_file, password):
    return decrypt(CAST, input_file, output_file, password)


def encrypt_rc2(input_file, output_name, password):
    return encrypt(RC2, input_file, output_name, password)


def decrypt_rc2(input_file, output_file, password):
    return decrypt(RC2, input_file, output_file, password)


def encrypt_rc4(input_file, output_name, password):
    return encrypt(RC4, input_file, output_name, password)


def decrypt_rc4(input_file, output_file, password):
    return decrypt(RC4, input_file, output_file, password)


def encrypt_sm4(input_file, output_name, password):
    return encrypt(SM4, input_file, output_name, password)


def decrypt_sm4(input_file, output_file, password):
    return decrypt(SM4, input_file, output_file, password)


def encrypt_chacha20(input_file, output_name, password):
    return encrypt(CHACHA20, input_file, output_name, password)


def decrypt_chacha20(input_file, output_file, password):
    return decrypt(CHACHA20, input_file, output_file, password)


def encrypt_camelia(input_file, output_name, password):
    return encrypt(CAMELLIA, input_file, output_name, password)


def decrypt_camelia(input_file, output_file, password):
    return decrypt(CAMELLIA, input_file, output_file, password)
