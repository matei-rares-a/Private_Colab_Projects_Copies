import importlib
import inspect
import os
import random
import time
import tkinter as tk
import traceback
from tkinter import filedialog
from tkinter import ttk
from memory_profiler import memory_usage
import os
import psutil
import tracemalloc
import encryptions.asymmetric.ecc_ecies as ecc
import encryptions.asymmetric.elgamal_elgamal as elgamal
import encryptions.asymmetric.rsa_subprocess as rsa
import encryptions.symmetric.openssl_subprocess as sym
from db.db import init_database, add_file_entry, get_all_files_entries, close_db_session, is_algorithm_in_db, \
    add_algorithm_entry, add_encrypt_oper_entry, add_decrypt_oper_entry, remove_file_entry, get_all_algorithms_entries, \
    get_all_operations_entries, get_all_keys_entries, recheck_files_entries, get_algorithm_id, get_key_id, is_key_in_db, \
    add_key_entry, get_file_path, get_all_available_files_entries, get_operations_data, get_alg_operations_data, \
    is_file_in_db, replace_file_details, get_algorithm_by_id

symmetrical_algorithms = {
    "AES": {"Encryption": sym.encrypt_aes,
            "Decryption": sym.decrypt_aes},
    "DES": {"Encryption": sym.encrypt_des,
            "Decryption": sym.decrypt_des},
    "3DES": {"Encryption": sym.encrypt_3des,
             "Decryption": sym.decrypt_3des},
    "Blowfish": {"Encryption": sym.encrypt_blowfish,
                 "Decryption": sym.decrypt_blowfish},
    "CAST": {"Encryption": sym.encrypt_cast,
             "Decryption": sym.decrypt_cast},
    "RC2": {"Encryption": sym.encrypt_rc2,
            "Decryption": sym.decrypt_rc2},
    "RC4": {"Encryption": sym.encrypt_rc4,
            "Decryption": sym.decrypt_rc4},
    "SM4": {"Encryption": sym.encrypt_sm4,
            "Decryption": sym.decrypt_sm4},
    "ChaCha20": {"Encryption": sym.encrypt_chacha20,
                 "Decryption": sym.decrypt_chacha20},
    "Camellia": {"Encryption": sym.encrypt_camelia,
                 "Decryption": sym.decrypt_camelia}

}

asymmetrical_algorithms = {
    "RSA": {"Encryption": rsa.encrypt_file,
            "Decryption": rsa.decrypt_file,
            "Generate": rsa.generate_keys},
    # "ECC": {"Encryption": ecc.encrypt_file,
    #         "Decryption": ecc.decrypt_file,
    #         "Generate": ecc.generate_keys},
    # "ElGamal": {"Encryption": elgamal.encrypt_file,
    #             "Decryption": elgamal.decrypt_file,
    #             "Generate": elgamal.generate_keys}
}

internal_algorithms = {
    "Symmetrical": symmetrical_algorithms,
    "Asymmetrical": asymmetrical_algorithms
}

was_file_selected = False
function_file_path = None


def my_memory_usage():
    process = psutil.Process()
    mem = process.memory_info().rss  # octet #/ (1024 ** 2)  # MB
    # mem = process.memory_info().shared  # octet #/ (1024 ** 2)  # MB
    return mem


def init():
    def apply_algorithm(file_path, algorithm, operation_type, key, external_function_option, encryption_type,
                        output_dir="", mode="normal"):
        try:
            if is_file_in_db(entry_file_path.get())== False:
                add_file_entry(entry_file_path.get())
            file_size= os.path.getsize(file_path)
            if mode == "normal":
                if file_size > 1000 and encryption_type == "Asymmetrical" :
                    confirmation = tk.messagebox.askyesno("Confirmation", "The file is too big and it might take a long time to finish the operation. Do you want to continue?")
                    if confirmation == False:
                        return
            start_time = time.time()
            if not was_file_selected and not mode == "encrypt_all_with":
                tk.messagebox.showerror("Error", "No file was selected!")
                return
            if external_function_option == "ON":
                if not function_file_path:
                    tk.messagebox.showerror("Error", "No function file was selected!")
                    return
                function_name, function = load_function_from_file(function_file_path)
                if not function_name or not function:
                    tk.messagebox.showerror("Error", "Function loading failed!")
                    return
                if not is_algorithm_in_db(function_name, "1.0"):
                    algorithm_id = add_algorithm_entry(function_name, "1.0",
                                                       function_file_path, encryption_type, "External")
                else:
                    algorithm_id = get_algorithm_id(algorithm, "1.0")
            else:
                if not is_algorithm_in_db(algorithm, "1.0"):
                    algorithm_id = add_algorithm_entry(algorithm, "1.0",
                                                       "", encryption_type,
                                                       "Internal")
                else:
                    algorithm_id = get_algorithm_id(algorithm, "1.0")
                function = internal_algorithms[encryption_type][algorithm][operation_type]

            if encryption_type == "Symmetrical":
                if not is_key_in_db(key):
                    key_id = add_key_entry(key)
                else:
                    key_id = get_key_id(key)
            else:
                if operation_type == "Encryption":
                    public_key, private_key = internal_algorithms[encryption_type][algorithm]["Generate"](file_size *16)
                    if not is_key_in_db(public_key):
                        if not is_key_in_db(private_key):
                            private_key_id = add_key_entry(private_key)
                            key_id = add_key_entry(public_key, private_key_id)
                        else:
                            key_id = add_key_entry(public_key, get_key_id(private_key))
                    else:
                        if not is_key_in_db(private_key):
                            private_key_id = add_key_entry(private_key)
                            key_id = add_key_entry(public_key, private_key_id)
                        else:
                            key_id = get_key_id(public_key)
                    key = public_key
                else:
                    if is_key_in_db(key):
                        key_id = get_key_id(key)
                    else:
                        tk.messagebox.showerror("Error", "No private key was found in database!")
                        return

            ''' saves output in the same directory as the input file'''

            output_path = name_output_file(file_path, operation_type, algorithm, output_dir)


            before = my_memory_usage()

            proc = function(file_path, output_path, key)

            # tracemalloc.start()
            # print("malloc",tracemalloc.get_traced_memory())
            # profi=memory_usage((function,(file_path, output_path, key),{}),interval=0.2)
            # print("profiler",profi)
            # print("profiler current", memory_usage(-1))

            memory = None
            if proc != None:
                process = psutil.Process(proc.pid)
                memory = process.memory_info().rss
                print("pid", memory)
            else:
                memory = my_memory_usage() - before
                print("process", memory)

            execution_time = time.time() - start_time


            if is_file_in_db(output_path):
                replace_file_details(output_path)
            else:
                try:
                    add_file_entry(output_path)
                except FileNotFoundError:
                    print()

            if operation_type == "Encryption":
                add_encrypt_oper_entry(file_path, algorithm_id, key_id, execution_time, memory)
                if encryption_type == "Asymmetrical" and mode == "normal":
                   popup_private_key(private_key + "|" , execution_time, memory)
            elif operation_type == "Decryption":
                add_decrypt_oper_entry(file_path, algorithm_id, key_id, execution_time, memory)
            else:
                tk.messagebox.showerror("Error", "Invalid operation type!")

            if mode == "normal" and encryption_type != "Asymmetrical" :
                tk.messagebox.showinfo("Success",
                                       f"Operation took {execution_time} seconds and {memory} bytes of memory!")
        except Exception as e:
            traceback.print_exc()
            tk.messagebox.showerror("Error", str(e))

    def name_output_file(file_path, operation_type, algorithm_name, output_dir):
        file_dir = os.path.dirname(file_path) if output_dir == "" else output_dir
        file_name = os.path.basename(file_path)
        name = os.path.splitext(file_name)[0].replace("_En_" + algorithm_name, "")
        file_type = os.path.splitext(file_name)[1]
        additional = "En" if operation_type == "Encryption" else "De"
        output_file_name = name + "_" + additional + "_" + algorithm_name + file_type
        return file_dir + "/" + output_file_name

    def load_function_from_file(file_path):
        directory, module_name = os.path.split(file_path)
        module_name = os.path.splitext(module_name)[0]

        spec = importlib.util.spec_from_file_location(module_name, file_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        for name, obj in inspect.getmembers(module):
            if inspect.isfunction(obj):
                if len(inspect.signature(obj).parameters) == 3:
                    return name, obj
        return None, None

    def open_file_dialog():
        global was_file_selected
        last_dir_file = open("others/last_directory.txt", "w+")
        last_dir_path = last_dir_file.readline().strip() if last_dir_file.readline() else ""

        file_path = filedialog.askopenfilename(initialdir=last_dir_path)
        if not file_path:
            was_file_selected = False
            return
        entry_file_path.config(state='normal')
        entry_file_path.delete(0, tk.END)
        entry_file_path.insert(0, file_path)
        entry_file_path.config(state='readonly')
        was_file_selected = True
        last_dir_file.write(file_path)
        tk.messagebox.showinfo("Success", "File selected!")

    def popup_private_key(private_key,execution_time, memory):
        popup = tk.Toplevel()
        popup.title("Select public key")
        popup.geometry("550x500")
        tk.messagebox.showinfo("Success",
                               f"Operation took {execution_time} seconds and {memory} bytes of memory!")
        text = tk.Text(popup, wrap=tk.WORD, height=5, width=30)
        private_key = str(private_key).strip("\n").strip(" ")
        text.insert(tk.END, private_key)
        text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        popup.mainloop()

    def popup_data(title, data):
        popup = tk.Toplevel()
        popup.title(title)
        popup.geometry("530x500")
        popup.focus_set()

        def on_escape(event):
            popup.destroy()

        popup.bind("<Escape>", on_escape)

        scrollbar = tk.Scrollbar(popup)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        text = tk.Text(popup, wrap=tk.WORD, height=5, width=30, yscrollcommand=scrollbar.set)
        data = str(data)
        text.insert(tk.END, data)
        text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        scrollbar.config(command=text.yview)
        popup.mainloop()

    def open_file_function_dialog():
        global function_file_path
        function_file_path = filedialog.askopenfilename()
        if not function_file_path:
            return
        entry_function_file_path.config(state='normal')
        entry_function_file_path.delete(0, tk.END)
        entry_function_file_path.insert(0, function_file_path)
        entry_function_file_path.config(state='readonly')
        try:
            function_name, function = load_function_from_file(function_file_path)
            if not function_name or not function:
                tk.messagebox.showerror("Error", "No function was identified in the file! Try with another file!")
                return
            else:
                tk.messagebox.showinfo("Success", "Function was successfully identified! Name: " + function_name)
        except Exception as e:
            tk.messagebox.showerror("Error",
                                    "Error while identifying function from file: " +
                                    str(e) + " ! Try with another file!")

    def update_algorithm_dropdown(*args):
        if encryption_type.get() == "Symmetrical":
            encryption_algorithm_dropdown['menu'].delete(0, 'end')
            for algo in symmetrical_algorithms.keys():
                encryption_algorithm_dropdown['menu'].add_command(label=algo,
                                                                  command=tk._setit(algorithm, algo))
            algorithm.set(next(iter(symmetrical_algorithms.keys())))
        elif encryption_type.get() == "Asymmetrical":
            encryption_algorithm_dropdown['menu'].delete(0, 'end')
            for algo in asymmetrical_algorithms.keys():
                encryption_algorithm_dropdown['menu'].add_command(label=algo,
                                                                  command=tk._setit(algorithm, algo))
            algorithm.set(next(iter(asymmetrical_algorithms.keys())))

    def add_file_to_db():
        try:
            if not was_file_selected:
                raise Exception("No file was selected!")
            if is_file_in_db(entry_file_path.get()):
                tk.messagebox.showerror("Error", "File already in database!")
                return
            add_file_entry(entry_file_path.get())
            tk.messagebox.showinfo("Success", "File added to database!")
        except Exception as e:
            tk.messagebox.showerror("Error", str(e))

    def remove_file_from_db():
        try:
            if not was_file_selected:
                raise Exception("No file was selected!")
            remove_file_entry(entry_file_path.get())
            tk.messagebox.showinfo("Success", "File removed from database!")
        except Exception as e:
            tk.messagebox.showerror("Error", str(e))

    def encrypt_with_all():
        global function_file_path
        try:
            if not was_file_selected:
                raise Exception("No file was selected!")

            algorithms = get_all_algorithms_entries()
            for alg in algorithms:
                operation_type = "Encryption"
                file_size= os.path.getsize(entry_file_path.get())
                if file_size > 1000 and alg.algorithm_type == "Asymmetrical":
                    continue
                if alg.algorithm_location == "Internal":
                    apply_algorithm(entry_file_path.get(), alg.algorithm_name, operation_type, entry_key.get(), "OFF",
                                    alg.algorithm_type, mode="encrypt_with_all")
                else:
                    function_file_path = alg.algorithm_description
                    apply_algorithm(entry_file_path.get(), alg.algorithm_name, operation_type, entry_key.get(), "ON",
                                    alg.algorithm_type, mode="encrypt_with_all")

            tk.messagebox.showinfo("Success", "File encrypted with all algorithms!")
        except Exception as e:
            tk.messagebox.showerror("Error", str(e))

    def encrypt_all_with():
        try:
            recheck_files_entries()
            files = get_all_available_files_entries()

            for file in files:
                print(file.file_path)
                if file.file_size > 1000 and encryption_type.get() == "Asymmetrical":
                    print(file.file_size)
                    continue
                apply_algorithm(file.file_path, algorithm.get(), operation_type.get(), entry_key.get(),
                                external_function_option.get(), encryption_type.get(), output_dir="", #output_dir="others"
                                mode="encrypt_all_with")

            tk.messagebox.showinfo("Success", "All files encrypted with selected algorithm!")
        except Exception as e:
            tk.messagebox.showerror("Error", str(e))

    def toggle_operation():
        operation_label.config(text=selected_operation.get() + " ")
        if operation_label.cget("text") == "DB oper ON ":
            for widget in group2_widgets:
                widget.config(state=tk.DISABLED)
            for widget in group1_widgets:
                widget.config(state=tk.NORMAL)
        else:
            for widget in group1_widgets:
                widget.config(state=tk.DISABLED)
            for widget in group2_widgets:
                widget.config(state=tk.NORMAL)



    def display_time_graphs():
        import matplotlib.pyplot as plt
        operations = get_all_operations_entries()

        dataset1 = {}
        dataset2 = {}
        for op in operations:
            if op.algorithm_id in [14]:
                continue
            if op.operation_type == "crypt":
                if op.algorithm_id not in dataset1:
                    dataset1[op.algorithm_id] = []#(0,0)]
                dataset1[op.algorithm_id].append((op.memory_consumed, op.time_consumed))
            else:
                if op.algorithm_id not in dataset2:
                    dataset2[op.algorithm_id] = []
                dataset2[op.algorithm_id].append((op.memory_consumed, op.time_consumed))

        for algorithm_id, data in dataset1.items():
            dataset1[algorithm_id] = sorted(data, key=lambda x: x[0])
        for algorithm_id, data in dataset2.items():
            dataset2[algorithm_id] = sorted(data, key=lambda x: x[0])

        print(dataset1)
        print(dataset2)

        fig = plt.figure(figsize=(14, 8))
        ax1 = fig.add_subplot(2, 2, 1)
        ax1a= fig.add_subplot(2, 2, 2)
        ax2 = fig.add_subplot(2, 2, 3)
        ax2a= fig.add_subplot(2, 2, 4)
        plt.subplots_adjust(hspace=0.4)
        plt.subplots_adjust(wspace=0.1)
        for algorithm_id, data in dataset1.items():
            alg= get_algorithm_by_id(algorithm_id)
            if alg.algorithm_type == "Symmetrical":

                x_values = [point[0] for point in data]
                y_values = [point[1] for point in data]
                ax1.plot(x_values, y_values, label=str(alg.algorithm_name))
            else:
                x_values = [point[0] for point in data]
                y_values = [point[1] for point in data]
                ax1a.plot(x_values, y_values, label=str(alg.algorithm_name))


        for algorithm_id, data in dataset2.items():
            alg= get_algorithm_by_id(algorithm_id)
            if alg.algorithm_type == "Symmetrical":
                x_values = [point[0] for point in data]
                y_values = [point[1] for point in data]
                ax2.plot(x_values, y_values, label=str(alg.algorithm_name))
            else:
                x_values = [point[0] for point in data]
                y_values = [point[1] for point in data]
                ax2a.plot(x_values, y_values, label=str(alg.algorithm_name))



        ax1.set_xlabel('Memory Used (bytes)')
        ax1.set_ylabel('Time (s)')
        ax1.set_title('Encryptions symmetrical')
        ax1.legend()

        ax1a.set_xlabel('Memory Used (bytes)')
        ax1a.set_ylabel('Time (s)')
        ax1a.set_title('Encryptions asymmetrical')
        ax1a.legend()


        ax2.set_xlabel('Memory Used (bytes)')
        ax2.set_ylabel('Time (s)')
        ax2.set_title('Decryptions symnetrical')
        ax2.legend()

        ax2a.set_xlabel('Memory Used (bytes)')
        ax2a.set_ylabel('Time (s)')
        ax2a.set_title('Decryptions asymmetrical')
        ax2a.legend()

        plt.show()

    def list_files():
        try:
            files = get_all_available_files_entries()
            if not files or len(files) == 0:
                tk.messagebox.showinfo("Files", "No files in database!")
                return
            popup_data("Files", "Files: \n" + "\n".join([file.file_path for file in files]))
        except Exception as e:
            tk.messagebox.showerror("Error", str(e))

    def list_algorithms():
        try:
            algorithms = get_all_algorithms_entries()
            if not algorithms or len(algorithms) == 0:
                tk.messagebox.showinfo("Alghoritms", "No alghoritms in database!")
                return
            popup_data("Alghoritms", "Alghoritms: \n" + "\n".join([algo.algorithm_name for algo in algorithms]))

        except Exception as e:
            tk.messagebox.showerror("Error", str(e))

    def list_operations():
        try:
            operations = get_all_operations_entries()
            if not operations or len(operations) == 0:
                tk.messagebox.showinfo("Operations", "No operations in database!")
                return
            popup_data("Operations", "Operations: \n" + "\n".join([get_file_path(oper.file_id) for oper in operations]))
        except Exception as e:
            tk.messagebox.showerror("Error", str(e))

    def list_keys():
        try:
            keys = get_all_keys_entries()
            if not keys or len(keys) == 0:
                tk.messagebox.showinfo("Keys", "No keys in database!")
                return
            popup_data("Keys", "Keys: \n" + "\n".join([str(key.key_id) + ":" + str(key.key_value) for key in keys]))
        except Exception as e:
            tk.messagebox.showerror("Error", str(e))

    def recheck_files():
        try:
            count = recheck_files_entries()
            if count == 0:
                tk.messagebox.showinfo("Success", "No files updated!")
            else:
                tk.messagebox.showinfo("Success",
                                       "Files rechecked and available files updated! " + str(count) + " files!")
        except Exception as e:
            tk.messagebox.showerror("Error", str(e))

    def display_statistics():
        count_asym, mem_asym, tim_asym = get_alg_operations_data("Asymmetrical")
        if count_asym > 0:
            avg_mem_asym = mem_asym / count_asym
            avg_time_asym = tim_asym / count_asym
        else:
            avg_mem_asym = 0
            avg_time_asym = 0

        count_sym, mem_sym, tim_sym = get_alg_operations_data("Symmetrical")
        if count_sym > 0:
            avg_mem_sym = mem_sym / count_sym
            avg_time_sym = tim_sym / count_sym
        else:
            avg_mem_sym = 0
            avg_time_sym = 0

        count_op, mem, tim = get_operations_data()
        if count_op > 0:
            avg_mem_op = mem / count_op
            avg_time_op = tim / count_op
        else:
            avg_mem_op = 0
            avg_time_op = 0

        data = (
                f"For {count_op} operations, average memory usage is {avg_mem_op:.2f} MB, and time is: {avg_time_op:.2f} s\n" +
                f"For {count_asym} asymmetric operations, average memory usage is {avg_mem_asym:.2f} MB, and time is: {avg_time_asym:.2f} s\n" +
                f"For {count_sym} symmetric operations, average memory usage is {avg_mem_sym:.2f} MB, and time is: {avg_time_sym:.2f} s\n"
        )
        popup_data("Statistics", data)

    window = tk.Tk()
    window.title("File Encryption/Decryption Tool")

    fixed_window_width = 520
    fixed_window_height = 720

    window.resizable(False, False)
    window.geometry(f"{fixed_window_width}x{fixed_window_height}")

    index_row = 0
    index_column = 0

    padx_value = (10, 10)
    pady_value = (10, 5)

    button = tk.Button(window, text="Select file", command=lambda: open_file_dialog())
    button.grid(row=index_row, column=index_column, padx=padx_value, pady=pady_value, sticky="w")
    index_row += 1
    tk.Label(window, text="File selected: ").grid(row=index_row, column=index_column, padx=padx_value, pady=pady_value,
                                                  sticky="w")
    entry_file_path = tk.Entry(window, state='readonly', width=45)
    entry_file_path.grid(row=index_row, column=index_column + 1, padx=padx_value, pady=pady_value, sticky="w",
                         columnspan=8)
    index_row += 1
    selected_operation = tk.StringVar()
    selected_operation.set("Database operations")
    toggle_button = ttk.Checkbutton(window, text="Toggle operation: ", variable=selected_operation,
                                    command=toggle_operation,
                                    onvalue="File oper ON", offvalue="DB oper ON")
    toggle_button.grid(row=index_row, column=index_column, padx=padx_value, pady=pady_value, sticky="w")
    operation_label = tk.Label(window, text="DB oper ON")
    operation_label.grid(row=index_row, column=index_column + 1, padx=padx_value,
                         pady=pady_value, sticky="w")
    index_row += 1

    ### group 1 widgets
    label0 = tk.Label(window, text="Database operations: ")
    label0.grid(row=index_row, column=index_column, padx=padx_value,
                pady=pady_value, sticky="w")
    index_row += 1
    label1 = tk.Label(window, text="Single operations: ")
    label1.grid(row=index_row, column=index_column, padx=padx_value,
                pady=pady_value, sticky="w")
    button1 = tk.Button(window, text="Add file", command=add_file_to_db)
    button1.grid(row=index_row, column=index_column + 1, padx=padx_value, pady=pady_value, sticky="w")
    button2 = tk.Button(window, text="Remove file", command=remove_file_from_db)
    button2.grid(row=index_row, column=index_column + 2, padx=padx_value, pady=pady_value, sticky="w")
    index_row += 1
    label2 = tk.Label(window, text="Multi operations: ")
    label2.grid(row=index_row, column=index_column, padx=padx_value, pady=pady_value, sticky="w")
    button3 = tk.Button(window, text="Encrypt with all", command=encrypt_with_all)
    button3.grid(row=index_row, column=index_column + 1, padx=padx_value, pady=pady_value, sticky="w")
    button4 = tk.Button(window, text="Encrypt all with", command=encrypt_all_with)
    button4.grid(row=index_row, column=index_column + 2, padx=padx_value, pady=pady_value, sticky="w")
    index_row += 1
    label8 = tk.Label(window, text="Database content: ")
    label8.grid(row=index_row, column=index_column, padx=padx_value, pady=pady_value, sticky="w")
    button7 = tk.Button(window, text="Recheck files", command=recheck_files)
    button7.grid(row=index_row, column=index_column + 1, padx=padx_value, pady=pady_value, sticky="w")
    button5 = tk.Button(window, text="List files", command=lambda: list_files())
    button5.grid(row=index_row, column=index_column + 2, padx=padx_value, pady=pady_value, sticky="w")
    index_row += 1
    button6 = tk.Button(window, text="List algorithms", command=lambda: list_algorithms())
    button6.grid(row=index_row, column=index_column + 2, padx=padx_value, pady=pady_value, sticky="w")
    button8 = tk.Button(window, text="List operations", command=lambda: list_operations())
    button8.grid(row=index_row, column=index_column + 1, padx=padx_value, pady=pady_value, sticky="w")
    button9 = tk.Button(window, text="List keys", command=lambda: list_keys())
    button9.grid(row=index_row, column=index_column + 3, padx=padx_value, pady=pady_value, sticky="w")
    index_row += 1
    label9 = tk.Label(window, text="Statistics: ")
    label9.grid(row=index_row, column=index_column, padx=padx_value, pady=pady_value, sticky="w")
    button10 = tk.Button(window, text="Show statistics", command=lambda: display_statistics())
    button10.grid(row=index_row, column=index_column + 1, padx=padx_value, pady=pady_value, sticky="w")
    button11 = tk.Button(window, text="Show graphs", command=lambda: display_time_graphs())
    button11.grid(row=index_row, column=index_column + 2, padx=padx_value, pady=pady_value, sticky="w")
    index_row += 1
    group1_widgets = [label1, button1, button2, label2, button3, button4, label0, label8, button5, button6, button7,
                      button8, button9, label9, button10, button11]
    ### end group 1 widgets

    ### group 2 widgets
    label3 = tk.Label(window, text="File operations: ")
    label3.grid(row=index_row, column=index_column, padx=padx_value,
                pady=pady_value, sticky="w")
    index_row += 1
    label4 = tk.Label(window, text="Algorithm Type: ")
    label4.grid(row=index_row, column=index_column, padx=padx_value,
                pady=pady_value, sticky="w")
    encryption_type = tk.StringVar()
    encryption_type.set("Symmetrical")
    symmetrical_radio = tk.Radiobutton(window, text="Symmetrical", variable=encryption_type, value="Symmetrical",
                                       command=update_algorithm_dropdown)
    symmetrical_radio.grid(row=index_row, column=index_column + 1, padx=padx_value, pady=pady_value, sticky="w")

    asymmetrical_radio = tk.Radiobutton(window, text="Asymmetrical", variable=encryption_type, value="Asymmetrical",
                                        command=update_algorithm_dropdown)
    asymmetrical_radio.grid(row=index_row, column=index_column + 2, padx=padx_value, pady=pady_value, sticky="w")
    index_row += 1
    label5 = tk.Label(window, text="Algorithm: ")
    label5.grid(row=index_row, column=index_column, padx=padx_value, pady=pady_value, sticky="w")
    algorithm = tk.StringVar()
    algorithm.set(next(iter(symmetrical_algorithms.keys())))
    encryption_algorithm_dropdown = tk.OptionMenu(window, algorithm,
                                                  *symmetrical_algorithms.keys())
    encryption_algorithm_dropdown.grid(row=index_row, column=index_column + 1, columnspan=5, padx=padx_value,
                                       pady=pady_value, sticky="w")
    index_row += 1
    label6 = tk.Label(window, text="Operation Type: ")
    label6.grid(row=index_row, column=index_column, padx=padx_value, pady=pady_value, sticky="w")
    operation_type = tk.StringVar()
    operation_type.set("Encryption")
    new_encryption_radio = tk.Radiobutton(window, text="Encryption", variable=operation_type, value="Encryption",
                                          command=lambda: update_algorithm_dropdown("Encryption"))
    new_encryption_radio.grid(row=index_row, column=index_column + 1, padx=padx_value, pady=pady_value, sticky="w")

    new_decryption_radio = tk.Radiobutton(window, text="Decryption", variable=operation_type, value="Decryption",
                                          command=lambda: update_algorithm_dropdown("Decryption"))
    new_decryption_radio.grid(row=index_row, column=index_column + 2, padx=padx_value, pady=pady_value, sticky="w")
    index_row += 1
    label7 = tk.Label(window, text="Key: ")
    label7.grid(row=index_row, column=index_column, padx=padx_value, pady=pady_value, sticky="w")
    entry_key = tk.Entry(window, width=45)
    entry_key.grid(row=index_row, column=index_column + 1, padx=padx_value, pady=pady_value, sticky="w",
                   columnspan=8)
    index_row += 1
    label10 = tk.Label(window, text="External function: ")
    label10.grid(row=index_row, column=index_column, padx=padx_value, pady=pady_value, sticky="w")
    button11 = tk.Button(window, text="Select function file", command=lambda: open_file_function_dialog())
    button11.grid(row=index_row, column=index_column + 1, padx=padx_value, pady=pady_value, sticky="w")
    index_row += 1
    label11 = tk.Label(window, text="Function file: ")
    label11.grid(row=index_row, column=index_column, padx=padx_value, pady=pady_value, sticky="w")
    entry_function_file_path = tk.Entry(window, state='readonly', width=45)
    entry_function_file_path.grid(row=index_row, column=index_column + 1, padx=padx_value, pady=pady_value, sticky="w",
                                  columnspan=8)
    external_function_option = tk.StringVar()
    external_function_option.set("OFF")
    index_row += 1
    external_toggle_button = ttk.Checkbutton(window, text="Apply external function:", variable=external_function_option,
                                             onvalue="ON", offvalue="OFF")
    external_toggle_button.grid(row=index_row, column=index_column, padx=padx_value, pady=pady_value, sticky="w")
    index_row += 1
    load_button = tk.Button(window, text="Apply Algorithm",
                            command=lambda: apply_algorithm(entry_file_path.get(), algorithm.get(),
                                                            operation_type.get(), entry_key.get(),
                                                            external_function_option.get(), encryption_type.get()))
    load_button.grid(row=index_row, column=index_column, columnspan=5, padx=padx_value, pady=pady_value, sticky="w")
    index_row += 1
    group2_widgets = [label3, label4, symmetrical_radio, asymmetrical_radio, label5, encryption_algorithm_dropdown,
                      label6, new_encryption_radio, new_decryption_radio, label7, entry_key,
                      load_button, external_toggle_button, label10, button11]
    ### end of group 2 widgets

    for widget in group2_widgets:
        widget.config(state=tk.DISABLED)
    for widget in group1_widgets:
        widget.config(state=tk.NORMAL)

    window.mainloop()


if __name__ == "__main__":
    init_database()
    init()

    close_db_session()
