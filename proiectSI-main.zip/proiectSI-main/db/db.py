import hashlib
import os

from sqlalchemy import Column, String, Float, ForeignKey, CheckConstraint, BigInteger, Boolean, create_engine
from sqlalchemy.dialects.mysql import LONGTEXT
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import relationship, validates
from sqlalchemy.orm import sessionmaker, Session

project_absolute_path = os.path.dirname(__file__)
db_config_relative_path = "db.config"
db_config_full_path = os.path.join(project_absolute_path, db_config_relative_path)

Base = declarative_base()
session_maker: sessionmaker[Session] = None
DB_CONFIG = open(db_config_full_path, "r").read().strip()


def init_database():
    global session_maker
    try:
        engine = create_engine(DB_CONFIG,pool_size=40)
        Base.metadata.create_all(engine)
        session_maker = sessionmaker(bind=engine)
        session_maker().commit()
        # delete_all_keys_pair()
        # delete_all_keys()
    except Exception as e:
        raise e


def close_db_session():
    global session_maker
    try:
        session_maker.close_all()
    except Exception as e:
        raise e


def get_db_session():
    return session_maker()


class File(Base):
    __tablename__ = 'files'

    file_id = Column(BigInteger, primary_key=True)
    file_path = Column(String(200), nullable=False, unique=True)
    file_size = Column(BigInteger, nullable=False)
    file_hash = Column(String(200), nullable=False)
    is_available = Column(Boolean, default=True, nullable=False)
    operations = relationship('Operations', back_populates='file')

    @validates('file_path')
    def validate_file_path(self, key, file_path):
        if not os.path.exists(file_path):
            raise ValueError(f"Invalid file path: {file_path}")
        return file_path

    @validates('file_size')
    def validate_file_size(self, key, file_size):
        if file_size < 0:
            raise ValueError(f"Invalid file size: {file_size}")
        return file_size

    @validates('file_hash')
    def validate_file_hash(self, key, file_hash):
        if len(file_hash) != 64:
            raise ValueError(f"Invalid file hash: {file_hash}")
        return file_hash


class Algorithm(Base):
    __tablename__ = 'algorithms'

    algorithm_id = Column(BigInteger, primary_key=True)
    algorithm_name = Column(String(100), nullable=False)
    algorithm_version = Column(String(100), nullable=False)
    algorithm_description = Column(String(200))
    algorithm_type = Column(String(100), CheckConstraint('algorithm_type IN ("Symmetrical", "Asymmetrical")'),
                            nullable=False)
    algorithm_location = Column(String(200), CheckConstraint('algorithm_location IN ("Internal", "External")'),
                                nullable=False)
    operations = relationship('Operations', back_populates='algorithm')


class Key(Base):
    __tablename__ = 'keys'

    key_id = Column(BigInteger, primary_key=True)
    key_value = Column(LONGTEXT, nullable=False)
    operations = relationship('Operations', back_populates='key')

    key_pair_id = Column(BigInteger, ForeignKey('keys.key_id'), nullable=True)


class Operations(Base):
    __tablename__ = 'operations'

    operation_id = Column(BigInteger, primary_key=True)
    operation_type = Column(String(10), CheckConstraint('operation_type IN ("crypt", "decrypt")'), nullable=False)

    file_id = Column(BigInteger, ForeignKey('files.file_id'), nullable=False)
    file = relationship('File', back_populates='operations')

    algorithm_id = Column(BigInteger, ForeignKey('algorithms.algorithm_id'), nullable=False)
    algorithm = relationship('Algorithm', back_populates='operations')

    key_id = Column(BigInteger, ForeignKey('keys.key_id'), nullable=False)
    key = relationship('Key', back_populates='operations')

    time_consumed = Column(Float, nullable=False)
    memory_consumed = Column(Float, nullable=False)


def add_file_entry(file_path):
    session = get_db_session()
    file = File(file_path=file_path, file_size=os.path.getsize(file_path), file_hash=_calculate_file_hash(file_path))
    session.add(file)
    session.commit()
    file = session.query(File).filter(File.file_path == file_path).first()
    id = file.file_id
    session.close()
    return id


def replace_file_details(file_path):
    session = get_db_session()
    file = session.query(File).filter(File.file_path == file_path).first()
    print(file_path)
    file.file_size = os.path.getsize(file_path)
    file.file_hash = _calculate_file_hash(file_path)
    session.commit()
    session.close()


def _calculate_file_hash(file_path, hash_algorithm='sha256'):
    hasher = hashlib.new(hash_algorithm)
    with open(file_path, 'rb') as file:
        while chunk := file.read(4096):
            hasher.update(chunk)
    return hasher.hexdigest()

def delete_all_keys_pair():
    session = get_db_session()
    for elem in session.query(Key):
        if elem.key_pair_id is not None:
            session.delete(elem)
    session.commit()
    session.close()

def delete_all_keys():
    session = get_db_session()
    for elem in session.query(Key):
        session.delete(elem)
    session.commit()
    session.close()

def add_key_entry(key_value, key_pair_id=None):
    session = get_db_session()
    key = None
    if key_pair_id:
        key = Key(key_value=key_value, key_pair_id=key_pair_id)
    else:
        key = Key(key_value=key_value)

    session.add(key)
    session.flush()
    session.refresh(key)
    id = key.key_id
    session.commit()
    session.close()
    return id


def add_algorithm_entry(algorithm_name, algorithm_version, algorithm_description, algorithm_type, algorithm_location):
    session = get_db_session()
    algorithm = Algorithm(algorithm_name=algorithm_name, algorithm_version=algorithm_version,
                          algorithm_description=algorithm_description, algorithm_type=algorithm_type,
                          algorithm_location=algorithm_location)
    session.add(algorithm)
    session.flush()
    session.refresh(algorithm)
    id = algorithm.algorithm_id
    session.commit()
    session.close()
    return id


def add_encrypt_oper_entry(file_path, algorithm_id, key_id, time_consumed, memory_consumed=0):
    session = get_db_session()
    file = session.query(File).filter(File.file_path == file_path).first()
    _add_operation_entry(file.file_id, algorithm_id, key_id, "crypt", time_consumed, memory_consumed)


def add_decrypt_oper_entry(file_path, algorithm_id, key_id, time_consumed, memory_consumed=0):
    session = get_db_session()
    file = session.query(File).filter(File.file_path == file_path).first()
    _add_operation_entry(file.file_id, algorithm_id, key_id, "decrypt", time_consumed, memory_consumed)


def _add_operation_entry(file_id, algorithm_id, key_id, operation_type, time_consumed, memory_consumed):
    session = get_db_session()
    operation = Operations(file_id=file_id, algorithm_id=algorithm_id, key_id=key_id, operation_type=operation_type,
                           time_consumed=time_consumed, memory_consumed=memory_consumed)
    session.add(operation)
    id = operation.operation_id
    session.commit()
    session.close()
    return id


def is_algorithm_in_db(algorithm_name, algorithm_version):
    session = get_db_session()
    algorithm = session.query(Algorithm).filter(Algorithm.algorithm_name == algorithm_name,
                                                Algorithm.algorithm_version == algorithm_version).first()
    if algorithm is None:
        return False
    session.close()
    return algorithm is not None


def get_algorithm_id(algorithm_name, algorithm_version):
    session = get_db_session()
    algorithm = session.query(Algorithm).filter(Algorithm.algorithm_name == algorithm_name,
                                                Algorithm.algorithm_version == algorithm_version).first()
    id = algorithm.algorithm_id
    session.close()
    return id

def get_algorithm_by_id(algorithm_id):
    session = get_db_session()
    algorithm = session.query(Algorithm).filter(Algorithm.algorithm_id == algorithm_id).first()
    session.close()
    return algorithm

def is_key_in_db(key_value):
    session = get_db_session()
    key = session.query(Key).filter(Key.key_value == key_value).first()
    if key is None:
        return False
    session.close()
    return key is not None


def get_key_id(key_value):
    session = get_db_session()
    key = session.query(Key).filter(Key.key_value == key_value).first()
    session.close()
    return key.key_id


def get_all_files_entries():
    session = get_db_session()
    files = session.query(File).all()
    session.close()
    return files


def get_all_available_files_entries():
    session = get_db_session()
    files = session.query(File).filter(File.is_available == True).all()
    session.close()
    return files


def get_all_external_algorithms_entries():
    session = get_db_session()
    algorithms = session.query(Algorithm).filter(Algorithm.algorithm_location == "External").all()
    session.close()
    return algorithms


def get_all_algorithms_entries():
    session = get_db_session()
    algorithms = session.query(Algorithm).all()
    session.close()
    return algorithms


def get_all_keys_entries():
    session = get_db_session()
    keys = session.query(Key).all()
    session.close()
    return keys


def get_all_operations_entries():
    session = get_db_session()
    operations = session.query(Operations).all()
    session.close()
    return operations


def recheck_files_entries():
    count = 0
    session = get_db_session()
    for file in get_all_files_entries():
        if not os.path.exists(file.file_path):
            file.is_available = False
            session.add(file)
            session.commit()
            count += 1
    session.close()
    return count


def remove_file_entry(file_path):
    session = get_db_session()
    file = session.query(File).filter(File.file_path == file_path).first()
    delete_operations_for(file.file_id)
    session.delete(file)
    session.commit()
    session.close()


def delete_operations_for(file_id):
    session = get_db_session()
    for elem in session.query(Operations).filter(Operations.file_id == file_id):
        session.delete(elem)
    session.commit()
    session.close()


def is_file_in_db(file_path):
    session = get_db_session()
    file = session.query(File).filter(File.file_path == file_path).first()
    if file is None:
        return False
    id = file.file_id
    session.close()
    return id is not None


def get_file_path(file_id):
    session = get_db_session()
    file = session.query(File).filter(File.file_id == file_id).first()
    path = file.file_path
    session.close()
    return path


def get_alg_operations_data(type):
    session = get_db_session()
    alg = session.query(Operations).join(Algorithm).filter(Algorithm.algorithm_type == type).all()
    count_asym = len(alg)

    memory_consumed = 0
    time_consumed = 0
    for operation in alg:
        memory_consumed += operation.memory_consumed
        time_consumed += operation.time_consumed
    session.close()
    return count_asym, memory_consumed, time_consumed


def get_operations_data():
    session = get_db_session()
    operations = session.query(Operations).all()
    count = len(operations)

    memory_consumed = 0
    time_consumed = 0
    for operation in operations:
        memory_consumed += operation.memory_consumed
        time_consumed += operation.time_consumed
    session.close()
    return count, memory_consumed, time_consumed
